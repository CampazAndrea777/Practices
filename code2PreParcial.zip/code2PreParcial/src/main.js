var scene    = null,
    camera   = null,
    renderer = null,
    controls = null,
    vectorU  = {x:null, y:null, z:null},
    vectorV  = {x:null, y:null, z:null},
    origin   = new THREE.Vector3(0,0,0),
    figuresGeo = [],
    obj = null,
    count = 0,
    toAlter = null;

function start() {
    window.onresize = onWindowResize;
    initScene();
    animate();
}

function initScene(){
    scene  = new THREE.Scene();
    camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 ); // aspecto - desde donde veo a donde (dende donde veo)

    // renderer = new THREE.WebGLRenderer();  // En donde la voy a poner
    renderer = new THREE.WebGLRenderer({ canvas: document.querySelector("#app") });
    renderer.setClearColor(0x33A4FF); // 0x333333
    renderer.setSize( window.innerWidth, window.innerHeight ); // tamano total
    document.body.appendChild( renderer.domElement ); // agrego 

    var geometry = new THREE.BoxGeometry( 10, 10, 10 ,4, 4, 4);
    var material = new THREE.MeshBasicMaterial( { color: 0x00ff00,
                                                  wireframe: true} ); 

    var controls = new THREE.OrbitControls(camera, renderer.domElement);

    camera.position.set(0,20,100);
    controls.update();

    // camera.position.x = 20;
    camera.position.y = 10;
    camera.position.z = 15;

    createFloor(2000,2000,0x8FA1B1);
}

function createFloor(prmX,prmY,colorSet) {
    var geoFloor = new THREE.PlaneBufferGeometry( prmX, prmY );
    var matFloor = new THREE.MeshBasicMaterial({ color: colorSet,
                                                 wireframe: false});

    var mshFloor = new THREE.Mesh(geoFloor,matFloor);
    mshFloor.rotation.x = - Math.PI * 0.5;

    scene.add( mshFloor );
}

function createSpotlight( color ) {
    var newObj = new THREE.SpotLight( color, 2 );
    newObj.castShadow = true;
    newObj.angle = 0.3;
    newObj.penumbra = 0.2;
    newObj.decay = 2;
    newObj.distance = 50;
    return newObj;
}

function drawGrid() {
    var size = 50;
    var divisions = 50;

    var gridHelper = new THREE.GridHelper(size,divisions,0x444444 ,0xffffff);
    scene.add(gridHelper);

    var axesHelper = new THREE.AxesHelper(5);
    scene.add(axesHelper);
}

function animate(){
	requestAnimationFrame(animate);
	renderer.render(scene,camera);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function createACar() {
    const axesHelper = new THREE.AxesHelper( 5 );
    scene.add( axesHelper );

    //cuerpo del carro 
    const geometry = new THREE.BoxGeometry( 5, 4, 7 );
    const material = new THREE.MeshBasicMaterial( {color: document.getElementById("Color").value} );
    const cubito = new THREE.Mesh( geometry, material );
    scene.add( cubito );

    const geometry2 = new THREE.BoxGeometry( 5, 2, 7 );
    const cubito2 = new THREE.Mesh( geometry2, material );
    scene.add( cubito2 );
    
    cubito.position.y=2;
    cubito.position.x=0;
    cubito2.position.z=3;
    cubito2.position.x=0;
    cubito2.position.y=1;

    //Luces del carro 

    const geometry3 = new THREE.SphereGeometry(0.5, 32, 16 );
    const material3 = new THREE.MeshBasicMaterial( { color: 0xFFFFFF } );
    const sphere = new THREE.Mesh( geometry3, material3 );
    const sphere2 = new THREE.Mesh( geometry3, material3 );
    scene.add( sphere );
    scene.add( sphere2 );

    sphere.position.x=1;
    sphere.position.y=1;
    sphere.position.z=6.5;
    sphere2.position.x=-1;
    sphere2.position.y=1;
    sphere2.position.z=6.5;

    //Lantas del carro
    const geometry6 = new THREE.TorusGeometry( 0.9, 0.6, 10, 10);
    const material6 = new THREE.MeshBasicMaterial( { color: 0xC9C9C9 } );
    const torus = new THREE.Mesh( geometry6, material6 );
    const torus2 = new THREE.Mesh( geometry6, material6 );
    const torus3 = new THREE.Mesh( geometry6, material6 );
    const torus4 = new THREE.Mesh( geometry6, material6 );
    scene.add( torus ); scene.add( torus2 ); scene.add( torus3 ); scene.add( torus4 );
    torus.rotation.y=1.5;
    torus.position.x=-2.5;
    torus.position.z=2;
    torus.position.y=0.0;
    torus2.rotation.y=1.5;
    torus2.position.x=-2.5;
    torus2.position.z=-2;
    torus2.position.y=0.0;
    torus3.rotation.y=1.5;
    torus3.position.x=2.5;
    torus3.position.z=2;
    torus4.position.y=0.0;
    torus4.rotation.y=1.5;
    torus4.position.x=2.5;
    torus4.position.z=-2;
    torus4.position.y=0.0;
}
function createCarretera(){
    const geometry = new THREE.PlaneGeometry( 20, 100 );
    const material = new THREE.MeshBasicMaterial( {color: 0xffff00, side: THREE.DoubleSide} );
    const planito = new THREE.Mesh( geometry, material );
    planito.rotation.x=0.5*Math.PI;
    planito.position.y=-1;
    scene.add( planito);
    
}
function ChangeColor() {
    var Color= document.getElementById("Color").value;
    cubito.material.color.set(Color);
    cubito2.material.color.set(Color);
}